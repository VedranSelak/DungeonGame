package game;

public class Main {
	public static void main(String[] args){
		Dungeon d = new Dungeon(8,7,5,14,true);
		d.run();
		}
}
